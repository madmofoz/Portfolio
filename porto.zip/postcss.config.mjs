/** @type {import('postcss-load-config').Config} */
const config = {
  plugins: {
    '@tailwindcss/postcss': {}, // Ubah dari 'tailwindcss' ke '@tailwindcss/postcss'
  },
};

export default config;